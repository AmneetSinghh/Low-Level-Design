package com.backend.notesharing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoteSharingApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoteSharingApplication.class, args);
	}

}
