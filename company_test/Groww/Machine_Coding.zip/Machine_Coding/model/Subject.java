package Groww.Machine_Coding.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Subject {
    private int subjectId;
    private String name;
    private Class classNo;
    private Teacher teacher;

}

// maths.