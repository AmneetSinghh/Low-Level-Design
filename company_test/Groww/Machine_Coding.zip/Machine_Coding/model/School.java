package Groww.Machine_Coding.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class School {
}
