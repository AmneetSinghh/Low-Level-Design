package Groww.Machine_Coding;

import lombok.*;
public class Main {
    public static void main(String[] args) {
        System.out.println("groww interview");
    }
}
