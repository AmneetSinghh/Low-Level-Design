package com.appointment.booking.system.Appointment.booking.system.enums;

public enum CustomerOnboardingSource {
    LINKEDIN, BOT, WEBSITE, ANDROID_APP, IOS_APP
}
