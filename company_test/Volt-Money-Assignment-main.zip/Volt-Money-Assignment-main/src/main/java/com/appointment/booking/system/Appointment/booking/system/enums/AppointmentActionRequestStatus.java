package com.appointment.booking.system.Appointment.booking.system.enums;

public enum AppointmentActionRequestStatus {
    RESCHEDULE_REQUEST, CANCEL_REQUEST
}
