package com.appointment.booking.system.Appointment.booking.system.enums;

public enum OperatorStatus {
    IDLE,
    IN_APPOINTMENT,
    NOT_IN_SERVICE
}
