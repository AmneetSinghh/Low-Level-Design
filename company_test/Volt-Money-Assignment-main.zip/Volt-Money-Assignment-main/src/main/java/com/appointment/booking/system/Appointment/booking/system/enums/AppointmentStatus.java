package com.appointment.booking.system.Appointment.booking.system.enums;



public enum AppointmentStatus {
    BOOKED, CANCELLED, RESCHEDULED
}
