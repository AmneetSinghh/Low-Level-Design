assignemnt link : https://docs.google.com/document/u/1/d/e/2PACX-1vSEC38vFELKFI-JV3kFseLYnlQvwBQFhMPhCeTFVmCjN7DDPixQ8fZKR78uMqOIyBC9TS8aF3ypQbbn/pub

GUIDE - steps to run the program :


- install docker hub  https://docs.docker.com/desktop/install/mac-install/
- run command in terminal : docker run -e POSTGRES_PASSWORD=postgres --name pg1 postgres
- enter into postgres terminal: docker exec -it pg1 psql -U postgres
- clone the github repo and run it ( all db schema get created automatically )
- postman collection - https://api.postman.com/collections/14202196-2c1449d1-4c5c-40b3-849f-dae77e836dce?access_key=PMAT-01HPRHD25KDZXVBAB7ZX0QV77A

