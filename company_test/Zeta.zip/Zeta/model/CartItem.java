package Zeta.model;


import lombok.AllArgsConstructor;

@AllArgsConstructor
public class CartItem {
    private String prodcutId;
}

/*
milk, productId,

 */