package Zeta.model;

public class User {
    private String userId;
    private String name;
}
