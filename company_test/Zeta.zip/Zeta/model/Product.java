package Zeta.model;

public class Product {
    private String productId;
    private String name;// lays.
    private String capacity;
    private int amount;
    ///
    ///
}
