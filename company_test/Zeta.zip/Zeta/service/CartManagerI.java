package Zeta.service;

import Zeta.model.CartItem;

import java.util.List;


// cal
// List< CartItems> cartItems.

// cartItems
public interface CartManagerI {
    void addItem(CartItem cartItem);
    void removeItem(CartItem cartItem);
    List<CartItem> viewCart();
}
