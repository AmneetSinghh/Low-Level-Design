package Zeta.service;

import Zeta.service.states.VendingMachineState;

public class VendingMachine {
    VendingMachineState vendingMachineState;
}
