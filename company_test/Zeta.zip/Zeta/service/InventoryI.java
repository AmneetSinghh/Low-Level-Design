package Zeta.service;


import Zeta.model.Product;

/*

Map<   productId, int >


*/

// water ->
public interface InventoryI {
    void addProduct(int productId, int frequency); // water, frequency. ( add into databse )
    void removeProduct(int productId); //  from the inventory.
}


// Sandwich    count.


/*




 */