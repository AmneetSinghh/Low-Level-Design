package Zeta.service.states;

import Zeta.enums.Coin;
import Zeta.model.CartItem;

import java.util.List;

public class DispenseState implements VendingMachineState{
    @Override
    public void addCoins(Coin coin) {

    }

    @Override
    public void addItemIntoCart(CartItem cartItem) {

    }

    @Override
    public void removeItemFromCart(CartItem cartItem) {

    }

    @Override
    public List<CartItem> viewCart() {
        return null;
    }

    @Override
    public void submit() {

    }

    @Override
    public void dispense() {

    }

    @Override
    public void remainingChange() {

    }

    @Override
    public void cancelTransaction() {

    }

}
