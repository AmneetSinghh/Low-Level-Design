package Zeta.service.states;

import Zeta.enums.Coin;
import Zeta.model.CartItem;

import java.util.List;

public interface VendingMachineState {
    void addCoins(Coin coin) throws Exception;
    void addItemIntoCart(CartItem cartItem) throws Exception;
    void removeItemFromCart(CartItem cartItem) throws Exception;
    List<CartItem> viewCart() throws Exception;
    void submit() throws Exception;// check inventory and all validations.
    void dispense() throws Exception;// remaining change.
    void remainingChange();
    void cancelTransaction();
}
