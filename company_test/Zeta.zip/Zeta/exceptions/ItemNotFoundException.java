package Zeta.exceptions;

public class ItemNotFoundException extends RuntimeException{
    public ItemNotFoundException(String value){
    }
}
