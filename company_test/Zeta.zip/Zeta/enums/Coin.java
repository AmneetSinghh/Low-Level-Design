package Zeta.enums;

public enum Coin {
    FIVE(5),
    TEN(10),
    FIFTY(50),
    HUNDRED(100);

    private int coin;
    Coin(int coin) {
        this.coin = coin;
    }
    public int getCoin() {
        return coin;
    }
}


// vending machine ->



/*




 */