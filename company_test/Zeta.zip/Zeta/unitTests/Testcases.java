package Zeta.unitTests;

import Zeta.model.CartItem;
import Zeta.service.states.AcceptMoneyState;
import Zeta.service.states.VendingMachineState;

public class Testcases {

    public void testAcceptMoneyStateAddCart(){
        VendingMachineState vendingMachineState = new AcceptMoneyState();
        try{
            vendingMachineState.addItemIntoCart(new CartItem("item1"));
            System.out.println("Test failed");
        } catch(Exception e){
            System.out.println("Test passed");
        }
    }

    public void testAcceptMoneyStateRemoveCart(){
        VendingMachineState vendingMachineState = new AcceptMoneyState();
        try{
            vendingMachineState.removeItemFromCart(new CartItem("item1"));
            System.out.println("Test failed");
        } catch(Exception e){
            System.out.println("Test passed");
        }
    }

    public void testAcceptMoneyStateViewCart(){
        VendingMachineState vendingMachineState = new AcceptMoneyState();
        try{
            vendingMachineState.viewCart();
            System.out.println("Test failed");
        } catch(Exception e){
            System.out.println("Test passed");
        }
    }



}
